package com.example.sistemacompra;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private CheckBox chkArroz, chkLeite, chkCarne, chkFeijao,chkRefrigerante;
    private Button btnCalcularTotal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        chkArroz = findViewById(R.id.chkArroz);
        chkLeite = findViewById(R.id.chkLeite);
        chkCarne = findViewById(R.id.chkCarne);
        chkFeijao = findViewById(R.id.chkFeijao);
        chkRefrigerante = findViewById(R.id.chkRefrigerante);

        btnCalcularTotal = findViewById(R.id.btnCalcularTotal);


    }

    public void calcularTotal(View v)
    {
        double valor = 0;
        String resultado;

        if(chkArroz.isChecked())
        {
            valor += 12.35;
        }

        if(chkLeite.isChecked())
        {
            valor += 2.48;
        }

        if(chkCarne.isChecked())
        {
            valor += 23.99;
        }

        if(chkFeijao.isChecked())
        {
            valor += 4.30;
        }

        if(chkRefrigerante.isChecked())
        {
            valor += 5.09;
        }

        resultado = Double.toString(valor);

        Toast.makeText(this, resultado, Toast.LENGTH_SHORT).show();
    }

}