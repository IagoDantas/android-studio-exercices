package com.example.aula2109;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class Lista extends AppCompatActivity {

    private ListView lsvClientes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista);
        lsvClientes = findViewById(R.id.lsvClientes);

        // Fonte de dados
        String[] clientes = {"Iago","Henrique","Jadir","Aline Barros","Olimpio","Jeff","Rafaela","Prior"};

        // Adaptador do ListView
        ArrayAdapter<String> adaptador =
                new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, clientes);

        lsvClientes.setAdapter(adaptador); // Relaciona o adaptador ao componente ListView

        // Implementação do evento de click do item
        lsvClientes.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String nome = String.valueOf(parent.getAdapter().getItem(position));
                Toast.makeText(Lista.this, nome, Toast.LENGTH_SHORT).show();
            }
        });
    }
}
