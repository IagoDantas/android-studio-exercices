package com.example.leplaisirrestaurante;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
     private Button btnCalcularContaFinal;
     private EditText edtConsumoTotal, edtCouvertArtistico, edtDividirConta, edtTaxaServico, edtContaTotal, edtValorPessoa;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtConsumoTotal = findViewById(R.id.edtConsumoTotal);
        btnCalcularContaFinal = findViewById(R.id.btnCalcularContaFinal);
        edtCouvertArtistico = findViewById(R.id.edtCouvertArtistico);
        edtDividirConta = findViewById(R.id.edtDividirConta);
        edtTaxaServico = findViewById(R.id.edtTaxaServico);
        edtContaTotal = findViewById(R.id.edtContaTotal);
        edtValorPessoa = findViewById(R.id.edtValorPessoa);

    }


    public void calcularTotal(View v){

    }
}